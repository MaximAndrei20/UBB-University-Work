#include "Repository.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;


Repository::~Repository()
{
}

void Repository::addEventToData(const Event e)
{
	this->events.add(e);
}

void Repository::deleteEvent(const std::string& title)
{
    int pos = 0;
	for (auto it = this->events.begin(); it != this->events.end(); ++it, ++pos)
	{
		if (it->getTitle() == title)
		{
			this->events.remove(pos);
			return;
		}
	}
    std::string str = "";
	str += "Event with title ";
	str += title;
	str += " not found";
	throw std::runtime_error(str);
}

// Utility function to trim whitespace
std::string trim(const std::string& str) {
    auto start = str.begin();
    while (start != str.end() && std::isspace(*start)) {
        start++;
    }
    auto end = str.end();
    do {
        end--;
    } while (std::distance(start, end) > 0 && std::isspace(*end));
    return std::string(start, end + 1);
}

void Repository::readFromFile(std::string filename) {
    
    std::ifstream file(filename);

    if (!file) {
        throw std::runtime_error("Failed to open file: " + filename);
    }

    std::string line;
    int lineNumber = 0;

    while (std::getline(file, line)) {
        lineNumber++;
        line = trim(line);
        if (line.empty()) continue;  // Skip empty lines

        std::vector<std::string> parts;
        std::istringstream iss(line);
        std::string part;

        // Split by pipe character
        while (std::getline(iss, part, '|')) {
            parts.push_back(trim(part));
        }

        // Validate we got exactly 5 parts
        if (parts.size() != 5) {
            std::cerr << "Warning: Invalid format at line " << lineNumber
                << ". Expected 5 fields, got " << parts.size() << ". Skipping.\n";
            continue;
        }

        try {
            // Parse date and time
            std::tm tm = {};
            std::istringstream dateStream(parts[2]);
            dateStream >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
            if (dateStream.fail()) {
                throw std::runtime_error("Invalid date/time format");
            }
            auto dateTime = std::chrono::system_clock::from_time_t(std::mktime(&tm));

            // Parse number of people
            int numberOfPeople = std::stoi(parts[3]);

            // Create and add event
            Event event(
                parts[0],          // title
                parts[1],          // description
                dateTime,          // date and time
                numberOfPeople,    // number of people
                parts[4]           // link
            );

            this->addEventToData(event);
        }
        catch (const std::exception& e) {
            std::cerr << "Warning: Error parsing line " << lineNumber
                << ": " << e.what() << ". Skipping.\n";
            continue;
        }
    }
	file.close();
}

void Repository::writeToFile(std::string filename) {
    // 1. Open file with proper error checking
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::error_code ec(errno, std::system_category());
        throw std::runtime_error("Failed to open file for writing: " + ec.message());
    }

    // 2. Debug output
    std::cout << "Writing to file: " << filename << "\n";
    std::cout << "Number of events to write: " << this->events.getSize() << "\n";

    // 3. Write data with flush and error checking
    for (auto event : this->events) {
        file << event.toString() << "\n";
        if (file.fail()) {
            throw std::runtime_error("Failed to write to file");
        }
    }

}
