#include "Event.h"
#include <sstream>
#include <iomanip>
// Constructor
Event::Event(const std::string& title, const std::string& description, const std::chrono::system_clock::time_point& dateTime, int numberOfPeople, const std::string& link)
    : title(title), description(description), dateTime(dateTime), numberOfPeople(numberOfPeople), link(link) {
}

Event::~Event()
{
}

Event::Event(const Event& e)
{
	this->title = e.title;
	this->description = e.description;
	this->dateTime = e.dateTime;
	this->numberOfPeople = e.numberOfPeople;
	this->link = e.link;
}

Event& Event::operator=(const Event& e)
{
	this->title = e.title;
	this->description = e.description;
	this->dateTime = e.dateTime;
	this->numberOfPeople = e.numberOfPeople;
	this->link = e.link;
	return *this;
}

// Getters and setters
std::string Event::getTitle() const { return title; }
void Event::setTitle(const std::string& title) { this->title = title; }

std::string Event::getDescription() const { return description; }
void Event::setDescription(const std::string& description) { this->description = description; }

std::chrono::system_clock::time_point Event::getDateTime() const { return dateTime; }
void Event::setDateTime(const std::chrono::system_clock::time_point& dateTime) { this->dateTime = dateTime; }

int Event::getNumberOfPeople() const { return numberOfPeople; }
void Event::setNumberOfPeople(int numberOfPeople) { this->numberOfPeople = numberOfPeople; }

std::string Event::getLink() const { return link; }
void Event::setLink(const std::string& link) { this->link = link; }

std::string Event::toString() {
	std::ostringstream oss;
	std::time_t timeT = std::chrono::system_clock::to_time_t(dateTime);
	std::tm timeInfo;
	localtime_s(&timeInfo, &timeT);
	oss << title << " | " << description << " | " << std::put_time(&timeInfo, "%Y-%m-%d %H:%M:%S") << " | " << numberOfPeople << " | " << link;
	return oss.str();
}
