#pragma once
#include <string>
#include <chrono>

class Event
{
private:
    std::string title;
    std::string description;
    std::chrono::system_clock::time_point dateTime;
    int numberOfPeople;
    std::string link;

public:
    // Constructor
    Event(const std::string& title = "", const std::string& description = "", 
        const std::chrono::system_clock::time_point& dateTime = std::chrono::system_clock::now(), 
        int numberOfPeople = 0, const std::string& link = "");
    // Destructor
    ~Event();
	// Copy constructor
	Event(const Event& e);
	// Assignment operator
	Event& operator=(const Event& e);
    // Getters and setters
    std::string getTitle() const;
    void setTitle(const std::string& title);

    std::string getDescription() const;
    void setDescription(const std::string& description);

    std::chrono::system_clock::time_point getDateTime() const;
    void setDateTime(const std::chrono::system_clock::time_point& dateTime);

    int getNumberOfPeople() const;
    void setNumberOfPeople(int numberOfPeople);

    std::string getLink() const;
    void setLink(const std::string& link);

	std::string toString();
};