#pragma once
#include "Repository.h"
class Service
{
private:
	Repository repo;

public:
	Service(const Repository& repo) : repo{ repo } {}
	void addEvent(const std::string& title, const std::string& description, const std::chrono::system_clock::time_point& dateTime, int numberOfPeople, const std::string& link);
	void deleteEvent(const std::string& title);
	void updateEvent(const std::string& oldTitle, const std::string& title, const std::string& description, const std::chrono::system_clock::time_point& dateTime, int numberOfPeople, const std::string& link);
	DynamicVector<Event> getEvents() const { return this->repo.getEvents(); }
	Repository getRepo() const { return repo; }
};

