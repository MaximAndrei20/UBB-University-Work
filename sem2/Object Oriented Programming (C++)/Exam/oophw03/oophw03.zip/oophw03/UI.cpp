#include <iostream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <stdexcept>
#include <fstream>
#include <ctime>
#include "UI.h"
void UI::run()
{
	std::string mode;
	std::cout << "Choose mode (1 - administrator, 2 - user): ";
	std::cin >> mode;
	if (mode == "1")
	{
		bool running = true;
		while (running) {
			this->printAdminMenu();
			std::string command;
			
			std::cout << "Enter command: ";
			std::cin >> command;
			if (command == "0")
				running = false;
			else if (command == "1")
			{
				// display events
				DynamicVector<Event> events = this->service.getEvents();
				std::cout << "\n";
				// 20 11 85 9823 32 5834 823 0000
				for (auto it = events.begin(); it != events.end(); ++it)
				{
					std::cout << it->toString() << "\n\n";
				}
			}
			else if (command == "2") {
				// add event
				

				std::string title, description, link;
				std::chrono::system_clock::time_point dateTime;
				int numberOfPeople;
				std::cout << "Title: ";
				std::cin.ignore(); // Ignore any leftover newline character in the input buffer
				std::getline(std::cin, title);
				std::cout << "Description: ";
				
				std::getline(std::cin, description);
				std::cout << "Date and time (YYYY-MM-DD HH:MM:SS): ";
				std::string dateTimeStr;
				std::getline(std::cin, dateTimeStr);

				std::tm tm = {};
				std::istringstream ss(dateTimeStr);
				ss >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
				if (ss.fail()) {
					std::cout << "\nInvalid date and time\n\n";
					continue;
				}
				std::time_t timeT = std::mktime(&tm);
				dateTime = std::chrono::system_clock::from_time_t(timeT);

				std::cout << "Number of people: ";
				std::cin >> numberOfPeople;
				std::cout << "Link: ";
				std::cin >> link;
				this->service.addEvent(title, description, dateTime, numberOfPeople, link);
			}
			else if (command == "3")
			{
				// delete event
				std::string title;
				std::cout << "Title: ";
				std::cin.ignore(); // Ignore any leftover newline character in the input buffer
				std::getline(std::cin, title);
				try {
					this->service.deleteEvent(title);
				}
				catch (const std::exception& e) {
					std::cout << "\n" << e.what() << "\n\n";
					continue;
				}
				std::cout << "\nEvent deleted successfully!\n\n";
			}
			else if (command == "4")
			{
				// update event
				std::string oldTitle;
				std::cout << "Enter the title of the event to update: ";
				std::cin.ignore(); // Ignore any leftover newline character in the input buffer
				std::getline(std::cin, oldTitle);

				std::string title, description, link;
				int numberOfPeople;
				std::cout << "Title: ";
				std::getline(std::cin, title);
				std::cout << "Description: ";
				std::getline(std::cin, description);
				std::cout << "Date and time (YYYY-MM-DD HH:MM:SS): ";
				std::string dateTimeStr;
				std::getline(std::cin, dateTimeStr);

				std::tm tm = {};
				std::istringstream ss(dateTimeStr);
				ss >> std::get_time(&tm, "%Y-%m-%d %H:%M:%S");
				if (ss.fail()) {
					std::cout << "\nInvalid date and time\n\n";
					continue;
				}
				std::time_t timeT = std::mktime(&tm);

				std::chrono::system_clock::time_point dateTime;
				dateTime = std::chrono::system_clock::from_time_t(timeT);

				std::cout << "Number of people: ";
				std::cin >> numberOfPeople;
				std::cout << "Link: ";
				std::cin >> link;

				try{
					this->service.updateEvent(oldTitle, title, description, dateTime, numberOfPeople, link);
				}
				catch (const std::exception& e) {
					std::cout << "\n" << e.what() << "\n\n";
					continue;
				}
				std::cout << "\nEvent updated successfully!\n\n";
			}
			else
			{
				std::cout << "Invalid command!\n";
			}
		}
		this->writeToFile();
	}
	else if (mode == "2")
	{
		// user mode
	}
	else
	{
		std::cout << "Invalid mode!\n";
	}
}

void UI::printAdminMenu()
{
	std::cout << "1. Display events\n";
	std::cout << "2. Add event\n";
	std::cout << "3. Delete event\n";
	std::cout << "4. Update event\n";
	std::cout << "0. Exit\n";
}

void UI::writeToFile()
{
	std::ofstream file("DataBase.in");
	if (!file.is_open()) {
		std::cerr << "Failed to open file for writing\n";
		return;
	}
	DynamicVector<Event> events = this->service.getEvents();
	for (auto it = events.begin(); it != events.end(); ++it)
	{
		file << it->toString() << "\n";
	}
	file.close();
}
