#pragma once
#include "DynamicVector.h"
#include "Event.h"
class Repository
{
private:
	DynamicVector<Event> events;

public:
	Repository(const DynamicVector<Event>& e) : events(e) {}
	~Repository();
	void addEventToData(const Event e);
	void deleteEvent(const std::string& title);
	void updateEvent(const Event& e);
	void displayEvents() const;
	DynamicVector<Event> getEvents() const { return this->events; }
	int getNumberOfEvents() const { return events.getSize(); }
	void readFromFile(std::string filename);
	void writeToFile(std::string filename);
};

