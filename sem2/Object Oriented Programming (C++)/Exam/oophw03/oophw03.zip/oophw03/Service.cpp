#include "Service.h"

void Service::addEvent(const std::string& title, const std::string& description, const std::chrono::system_clock::time_point& dateTime, int numberOfPeople, const std::string& link)
{
	Event e{ title, description, dateTime, numberOfPeople, link };
	this->repo.addEventToData(e);
}

void Service::deleteEvent(const std::string& title)
{
	this->repo.deleteEvent(title);
}

void Service::updateEvent(const std::string& oldTitle, const std::string& title, const std::string& description, const std::chrono::system_clock::time_point& dateTime, int numberOfPeople, const std::string& link)
{
	Event e{ title, description, dateTime, numberOfPeople, link };
	this->repo.deleteEvent(oldTitle);
	this->repo.addEventToData(e);
}
